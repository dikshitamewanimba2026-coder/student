"""Custom exceptions for the Student Productivity App."""


class EmptyTitleError(ValueError):
    """Raised when a task title or subject is blank or whitespace only."""


class InvalidDeadlineError(ValueError):
    """Raised when a deadline is in the past or not a valid datetime."""


class InvalidPriorityError(ValueError):
    """Raised when a priority value is not in the allowed set."""


class InvalidHoursError(ValueError):
    """Raised when study hours are out of the allowed range (0 < hours <= 12)."""


class TaskNotFoundError(ValueError):
    """Raised when a task_id does not match any existing task."""
