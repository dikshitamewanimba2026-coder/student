"""Deadline reminder — detects tasks due within a configurable threshold."""

from __future__ import annotations

from datetime import datetime

from models import Task

DEFAULT_THRESHOLD_HOURS: float = 48.0


def get_due_soon_tasks(
    tasks: list[Task],
    threshold_hours: float = DEFAULT_THRESHOLD_HOURS,
) -> list[Task]:
    """Return pending tasks whose deadline is within *threshold_hours*.

    Parameters
    ----------
    tasks:
        Full list of tasks (any mix of complete/incomplete).
    threshold_hours:
        Number of hours ahead to look. Defaults to 48.

    Returns
    -------
    Incomplete, non-overdue tasks with ``0 < time_until_deadline <=
    threshold_hours``, sorted by deadline ascending (most urgent first).
    """
    threshold_seconds = threshold_hours * 3600
    now = datetime.now()
    due_soon: list[Task] = []

    for task in tasks:
        if task.is_complete:
            continue
        delta_seconds = (task.deadline - now).total_seconds()
        if 0 < delta_seconds <= threshold_seconds:
            due_soon.append(task)

    return sorted(due_soon, key=lambda t: t.deadline)
