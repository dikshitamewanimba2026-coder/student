"""Rule-based AI schedule suggester.

Algorithm
---------
Each pending, non-overdue task is scored with a *weighted urgency score*:

    score = (priority_weight / days_remaining) + priority_weight

Where ``priority_weight`` is 3 for High, 2 for Medium, 1 for Low.
This means:
- A task due tomorrow always beats one due in a week at the same priority.
- A High-priority task with equal time beats a Medium or Low one.

Tasks are sorted in *descending* score order (highest urgency first) and then
allocated into calendar days starting from today.  Each day is filled up to
``available_hours_per_day``, with at most ``MAX_HOURS_PER_TASK_PER_DAY`` hours
assigned to any single task on any single day.  A task whose deadline falls
*before* the day being filled is skipped (already overdue relative to that
future slot).
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import TypedDict

from exceptions import InvalidHoursError
from models import Task

MAX_HOURS_PER_TASK_PER_DAY: float = 2.0
_PRIORITY_WEIGHT: dict[str, int] = {"High": 3, "Medium": 2, "Low": 1}


class ScheduleEntry(TypedDict):
    """A single block of study time in the generated schedule."""
    task_id: str
    title: str
    subject: str
    priority: str
    hours: float


def _urgency_score(task: Task, today: date) -> float:
    """Compute a weighted urgency score for *task* relative to *today*.

    Higher score = more urgent = should be scheduled sooner.
    """
    weight = _PRIORITY_WEIGHT.get(task.priority, 1)
    days_remaining = max((task.deadline.date() - today).days, 0.5)  # avoid /0
    return (weight / days_remaining) + weight


def suggest_schedule(
    tasks: list[Task],
    available_hours_per_day: float,
) -> tuple[dict[date, list[ScheduleEntry]], bool]:
    """Generate a day-by-day study schedule for *tasks*.

    Parameters
    ----------
    tasks:
        The full list of tasks to schedule (pending + overdue are both
        passed in; the function filters to pending, non-overdue only).
    available_hours_per_day:
        How many hours the student can study per day (must be > 0).

    Returns
    -------
    A tuple of ``(schedule, all_scheduled)`` where:

    - ``schedule`` maps each :class:`~datetime.date` to a list of
      :class:`ScheduleEntry` dicts.
    - ``all_scheduled`` is ``True`` when every task received at least
      some study time.

    Raises
    ------
    InvalidHoursError: *available_hours_per_day* is <= 0.
    """
    if available_hours_per_day <= 0:
        raise InvalidHoursError("available_hours_per_day must be greater than 0.")

    today = date.today()

    # Filter: pending tasks whose deadline is still in the future
    eligible = [
        t for t in tasks
        if not t.is_complete and t.deadline.date() >= today
    ]

    if not eligible:
        return {}, True

    # Sort by descending urgency score (most urgent first)
    eligible.sort(key=lambda t: _urgency_score(t, today), reverse=True)

    schedule: dict[date, list[ScheduleEntry]] = {}
    # Track remaining hours each task still needs
    remaining: dict[str, float] = {t.task_id: MAX_HOURS_PER_TASK_PER_DAY * 2 for t in eligible}
    scheduled_ids: set[str] = set()

    current_day = today
    # Guard: don't run forever if hours are very limited
    max_days = 90

    for _ in range(max_days):
        if not eligible:
            break

        day_capacity = available_hours_per_day
        day_entries: list[ScheduleEntry] = []

        for task in eligible[:]:  # iterate a copy so we can remove safely
            if remaining[task.task_id] <= 0:
                continue
            # Don't schedule on or after the deadline day
            if current_day >= task.deadline.date():
                continue

            allocate = min(
                MAX_HOURS_PER_TASK_PER_DAY,
                remaining[task.task_id],
                day_capacity,
            )
            if allocate <= 0:
                break

            day_entries.append(
                ScheduleEntry(
                    task_id=task.task_id,
                    title=task.title,
                    subject=task.subject,
                    priority=task.priority,
                    hours=round(allocate, 2),
                )
            )
            remaining[task.task_id] = round(remaining[task.task_id] - allocate, 2)
            day_capacity = round(day_capacity - allocate, 2)
            scheduled_ids.add(task.task_id)

            if day_capacity <= 0:
                break

        if day_entries:
            schedule[current_day] = day_entries

        current_day += timedelta(days=1)

    all_scheduled = all(t.task_id in scheduled_ids for t in eligible)
    return schedule, all_scheduled
