"""Task management — CRUD operations and time-remaining logic."""

from __future__ import annotations

from datetime import datetime

import storage
from exceptions import (
    EmptyTitleError,
    InvalidDeadlineError,
    InvalidPriorityError,
    TaskNotFoundError,
)
from models import ALLOWED_PRIORITIES, Task

# Priority sort key: lower number = higher urgency
_PRIORITY_ORDER: dict[str, int] = {"High": 0, "Medium": 1, "Low": 2}


def add_task(
    title: str,
    subject: str,
    deadline: datetime,
    priority: str,
) -> Task:
    """Create a new task and persist it.

    Parameters
    ----------
    title:    Short name of the task (non-empty).
    subject:  Course or subject name (non-empty).
    deadline: Due date/time — must be in the future.
    priority: One of ``"High"``, ``"Medium"``, or ``"Low"``.

    Returns
    -------
    The newly created :class:`~models.Task`.

    Raises
    ------
    EmptyTitleError:       *title* or *subject* is blank/whitespace.
    InvalidDeadlineError:  *deadline* is not in the future.
    InvalidPriorityError:  *priority* is not an allowed value.
    """
    if not title or not title.strip():
        raise EmptyTitleError("Task title cannot be empty.")
    if not subject or not subject.strip():
        raise EmptyTitleError("Subject cannot be empty.")
    if deadline <= datetime.now():
        raise InvalidDeadlineError("Deadline must be a future date and time.")
    if priority not in ALLOWED_PRIORITIES:
        raise InvalidPriorityError(
            f"Priority must be one of {list(ALLOWED_PRIORITIES)}, got {priority!r}."
        )

    tasks = storage.load_tasks()
    task = Task(
        title=title.strip(),
        subject=subject.strip(),
        deadline=deadline,
        priority=priority,
    )
    tasks.append(task)
    storage.save_tasks(tasks)
    return task


def delete_task(task_id: str) -> None:
    """Remove the task with *task_id* from storage.

    Raises
    ------
    TaskNotFoundError: No task with the given ID exists.
    """
    tasks = storage.load_tasks()
    original_len = len(tasks)
    tasks = [t for t in tasks if t.task_id != task_id]
    if len(tasks) == original_len:
        raise TaskNotFoundError(f"No task found with id {task_id!r}.")
    storage.save_tasks(tasks)


def toggle_complete(task_id: str) -> Task:
    """Flip the ``is_complete`` flag on the task with *task_id*.

    Returns
    -------
    The updated :class:`~models.Task`.

    Raises
    ------
    TaskNotFoundError: No task with the given ID exists.
    """
    tasks = storage.load_tasks()
    for task in tasks:
        if task.task_id == task_id:
            task.is_complete = not task.is_complete
            storage.save_tasks(tasks)
            return task
    raise TaskNotFoundError(f"No task found with id {task_id!r}.")


def get_pending_tasks() -> list[Task]:
    """Return all incomplete tasks sorted by priority then nearest deadline."""
    tasks = storage.load_tasks()
    pending = [t for t in tasks if not t.is_complete]
    return sorted(pending, key=lambda t: (_PRIORITY_ORDER[t.priority], t.deadline, t.created_at))


def get_completed_tasks() -> list[Task]:
    """Return all completed tasks sorted by deadline ascending."""
    tasks = storage.load_tasks()
    completed = [t for t in tasks if t.is_complete]
    return sorted(completed, key=lambda t: t.deadline)


def get_time_remaining(task: Task) -> str:
    """Return a human-readable string for time remaining until *task*'s deadline.

    Returns ``"Overdue"`` when the deadline has already passed.
    Examples: ``"3 days, 4 hours"``, ``"5 hours, 30 minutes"``,
    ``"45 minutes"``.
    """
    delta = task.deadline - datetime.now()
    total_seconds = int(delta.total_seconds())

    if total_seconds <= 0:
        return "Overdue"

    days = total_seconds // 86400
    remaining = total_seconds % 86400
    hours = remaining // 3600
    remaining %= 3600
    minutes = remaining // 60

    parts: list[str] = []
    if days:
        parts.append(f"{days} day{'s' if days != 1 else ''}")
    if hours:
        parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
    if not parts:
        # Less than one hour
        parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
    elif len(parts) == 1 and not days:
        # Only hours shown — append minutes too for clarity
        if minutes:
            parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")

    return ", ".join(parts[:2])
