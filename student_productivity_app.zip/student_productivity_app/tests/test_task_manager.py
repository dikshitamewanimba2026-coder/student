"""Tests for task_manager.py — CRUD, validation, and time-remaining logic."""

from __future__ import annotations

from datetime import timedelta
from pathlib import Path

import pytest

import storage
import task_manager
from exceptions import (
    EmptyTitleError,
    InvalidDeadlineError,
    InvalidPriorityError,
    TaskNotFoundError,
)
from models import Task
from tests.conftest import future, past


@pytest.fixture(autouse=True)
def _tmp_data(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(storage, "DATA_DIR", tmp_path)
    monkeypatch.setattr(storage, "TASKS_FILE", tmp_path / "tasks.json")
    monkeypatch.setattr(storage, "LOGS_FILE", tmp_path / "logs.json")


# ---------------------------------------------------------------------------
# add_task
# ---------------------------------------------------------------------------

class TestAddTask:
    def test_valid_task_is_persisted(self) -> None:
        task = task_manager.add_task("Essay", "English", future(2), "High")
        assert task.title == "Essay"
        assert len(storage.load_tasks()) == 1

    def test_title_is_stripped(self) -> None:
        task = task_manager.add_task("  Lab Report  ", "Chemistry", future(2), "Low")
        assert task.title == "Lab Report"

    def test_blank_title_raises(self) -> None:
        with pytest.raises(EmptyTitleError):
            task_manager.add_task("   ", "Science", future(2), "Low")

    def test_blank_subject_raises(self) -> None:
        with pytest.raises(EmptyTitleError):
            task_manager.add_task("Essay", "  ", future(2), "Low")

    def test_past_deadline_raises(self) -> None:
        with pytest.raises(InvalidDeadlineError):
            task_manager.add_task("Essay", "English", past(1), "High")

    def test_invalid_priority_raises(self) -> None:
        with pytest.raises(InvalidPriorityError):
            task_manager.add_task("Essay", "English", future(2), "Critical")

    def test_all_three_priorities_accepted(self) -> None:
        for p in ("High", "Medium", "Low"):
            task_manager.add_task(f"Task {p}", "Subject", future(2), p)
        assert len(storage.load_tasks()) == 3


# ---------------------------------------------------------------------------
# delete_task
# ---------------------------------------------------------------------------

class TestDeleteTask:
    def test_delete_removes_task(self) -> None:
        task = task_manager.add_task("T", "S", future(2), "Low")
        task_manager.delete_task(task.task_id)
        assert storage.load_tasks() == []

    def test_delete_unknown_id_raises(self) -> None:
        with pytest.raises(TaskNotFoundError):
            task_manager.delete_task("nonexistent-id")


# ---------------------------------------------------------------------------
# toggle_complete
# ---------------------------------------------------------------------------

class TestToggleComplete:
    def test_toggle_marks_complete(self) -> None:
        task = task_manager.add_task("T", "S", future(2), "Medium")
        updated = task_manager.toggle_complete(task.task_id)
        assert updated.is_complete is True

    def test_toggle_twice_returns_to_incomplete(self) -> None:
        task = task_manager.add_task("T", "S", future(2), "Medium")
        task_manager.toggle_complete(task.task_id)
        updated = task_manager.toggle_complete(task.task_id)
        assert updated.is_complete is False

    def test_toggle_unknown_id_raises(self) -> None:
        with pytest.raises(TaskNotFoundError):
            task_manager.toggle_complete("bad-id")


# ---------------------------------------------------------------------------
# get_pending_tasks / get_completed_tasks
# ---------------------------------------------------------------------------

class TestGetTasks:
    def test_pending_excludes_completed(self) -> None:
        t1 = task_manager.add_task("T1", "S", future(2), "Low")
        task_manager.add_task("T2", "S", future(3), "Low")
        task_manager.toggle_complete(t1.task_id)
        pending = task_manager.get_pending_tasks()
        assert all(not t.is_complete for t in pending)
        assert len(pending) == 1

    def test_pending_sorted_high_before_low(self) -> None:
        task_manager.add_task("Low task", "S", future(2), "Low")
        task_manager.add_task("High task", "S", future(2), "High")
        pending = task_manager.get_pending_tasks()
        assert pending[0].priority == "High"
        assert pending[-1].priority == "Low"

    def test_pending_same_priority_sorted_by_deadline(self) -> None:
        task_manager.add_task("Later", "S", future(5), "Medium")
        task_manager.add_task("Sooner", "S", future(2), "Medium")
        pending = task_manager.get_pending_tasks()
        assert pending[0].title == "Sooner"

    def test_completed_only_returns_done(self) -> None:
        t1 = task_manager.add_task("T1", "S", future(2), "Low")
        task_manager.add_task("T2", "S", future(3), "Low")
        task_manager.toggle_complete(t1.task_id)
        completed = task_manager.get_completed_tasks()
        assert len(completed) == 1
        assert completed[0].is_complete is True


# ---------------------------------------------------------------------------
# get_time_remaining
# ---------------------------------------------------------------------------

class TestGetTimeRemaining:
    def test_overdue_returns_overdue(self) -> None:
        task = Task(title="T", subject="S", deadline=past(1), priority="Low")
        assert task_manager.get_time_remaining(task) == "Overdue"

    def test_future_returns_nonempty_string(self) -> None:
        task = Task(title="T", subject="S", deadline=future(3), priority="Low")
        result = task_manager.get_time_remaining(task)
        assert result != ""
        assert "Overdue" not in result

    def test_days_in_result_for_multi_day_deadline(self) -> None:
        task = Task(title="T", subject="S", deadline=future(5), priority="Low")
        result = task_manager.get_time_remaining(task)
        assert "day" in result

    def test_minutes_shown_for_sub_hour_deadline(self) -> None:
        from datetime import datetime
        task = Task(
            title="T", subject="S",
            deadline=datetime.now() + timedelta(minutes=30),
            priority="Low",
        )
        result = task_manager.get_time_remaining(task)
        assert "minute" in result
