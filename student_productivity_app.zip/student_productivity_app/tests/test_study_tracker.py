"""Tests for study_tracker.py — hour logging and summary queries."""

from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

import pytest

import storage
import study_tracker
from exceptions import EmptyTitleError, InvalidHoursError


@pytest.fixture(autouse=True)
def _tmp_data(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(storage, "DATA_DIR", tmp_path)
    monkeypatch.setattr(storage, "TASKS_FILE", tmp_path / "tasks.json")
    monkeypatch.setattr(storage, "LOGS_FILE", tmp_path / "logs.json")


# ---------------------------------------------------------------------------
# log_hours
# ---------------------------------------------------------------------------

class TestLogHours:
    def test_creates_new_log(self) -> None:
        log = study_tracker.log_hours("Math", date.today(), 2.0)
        assert log.hours == 2.0
        assert len(storage.load_logs()) == 1

    def test_accumulates_same_subject_same_date(self) -> None:
        study_tracker.log_hours("Math", date.today(), 1.0)
        log = study_tracker.log_hours("Math", date.today(), 1.5)
        assert log.hours == pytest.approx(2.5)
        assert len(storage.load_logs()) == 1  # still one record

    def test_different_subjects_create_separate_logs(self) -> None:
        study_tracker.log_hours("Math", date.today(), 1.0)
        study_tracker.log_hours("Science", date.today(), 1.0)
        assert len(storage.load_logs()) == 2

    def test_zero_hours_raises(self) -> None:
        with pytest.raises(InvalidHoursError):
            study_tracker.log_hours("Math", date.today(), 0)

    def test_negative_hours_raises(self) -> None:
        with pytest.raises(InvalidHoursError):
            study_tracker.log_hours("Math", date.today(), -1.0)

    def test_over_max_hours_raises(self) -> None:
        with pytest.raises(InvalidHoursError):
            study_tracker.log_hours("Math", date.today(), 13.0)

    def test_blank_subject_raises(self) -> None:
        with pytest.raises(EmptyTitleError):
            study_tracker.log_hours("  ", date.today(), 2.0)

    def test_exactly_max_hours_accepted(self) -> None:
        log = study_tracker.log_hours("Math", date.today(), 12.0)
        assert log.hours == 12.0


# ---------------------------------------------------------------------------
# get_weekly_hours
# ---------------------------------------------------------------------------

class TestGetWeeklyHours:
    def test_counts_today(self) -> None:
        study_tracker.log_hours("Math", date.today(), 3.0)
        assert study_tracker.get_weekly_hours() == pytest.approx(3.0)

    def test_excludes_last_week(self) -> None:
        today = date.today()
        # Monday of this week
        this_monday = today - timedelta(days=today.weekday())
        last_week_day = this_monday - timedelta(days=1)  # Sunday last week
        study_tracker.log_hours("Math", last_week_day, 5.0)
        study_tracker.log_hours("Math", today, 2.0)
        assert study_tracker.get_weekly_hours() == pytest.approx(2.0)

    def test_returns_zero_when_no_logs(self) -> None:
        assert study_tracker.get_weekly_hours() == 0.0


# ---------------------------------------------------------------------------
# get_hours_by_subject
# ---------------------------------------------------------------------------

class TestGetHoursBySubject:
    def test_aggregates_correctly(self) -> None:
        study_tracker.log_hours("Math", date.today(), 2.0)
        study_tracker.log_hours("Math", date.today() - timedelta(days=1), 1.0)
        study_tracker.log_hours("Physics", date.today(), 3.0)
        result = study_tracker.get_hours_by_subject()
        assert result["Math"] == pytest.approx(3.0)
        assert result["Physics"] == pytest.approx(3.0)

    def test_returns_empty_dict_when_no_logs(self) -> None:
        assert study_tracker.get_hours_by_subject() == {}
