"""Tests for reminder.py — due-soon task detection."""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest

import reminder
from models import Task
from tests.conftest import future, past


def _task(title: str, hours_from_now: float, is_complete: bool = False) -> Task:
    deadline = datetime.now() + timedelta(hours=hours_from_now)
    t = Task(title=title, subject="S", deadline=deadline, priority="Medium")
    t.is_complete = is_complete
    return t


class TestGetDueSoonTasks:
    def test_returns_task_within_threshold(self) -> None:
        tasks = [_task("Due soon", hours_from_now=24)]
        result = reminder.get_due_soon_tasks(tasks, threshold_hours=48)
        assert len(result) == 1
        assert result[0].title == "Due soon"

    def test_excludes_task_beyond_threshold(self) -> None:
        tasks = [_task("Far away", hours_from_now=72)]
        result = reminder.get_due_soon_tasks(tasks, threshold_hours=48)
        assert result == []

    def test_excludes_completed_tasks(self) -> None:
        tasks = [_task("Done", hours_from_now=10, is_complete=True)]
        result = reminder.get_due_soon_tasks(tasks, threshold_hours=48)
        assert result == []

    def test_excludes_overdue_tasks(self) -> None:
        overdue = Task(
            title="Overdue",
            subject="S",
            deadline=datetime.now() - timedelta(hours=1),
            priority="High",
        )
        result = reminder.get_due_soon_tasks([overdue], threshold_hours=48)
        assert result == []

    def test_sorted_by_deadline_ascending(self) -> None:
        tasks = [
            _task("Later", hours_from_now=40),
            _task("Sooner", hours_from_now=10),
        ]
        result = reminder.get_due_soon_tasks(tasks, threshold_hours=48)
        assert result[0].title == "Sooner"
        assert result[1].title == "Later"

    def test_default_threshold_is_48_hours(self) -> None:
        tasks = [
            _task("Within 48h", hours_from_now=47),
            _task("Outside 48h", hours_from_now=49),
        ]
        result = reminder.get_due_soon_tasks(tasks)
        assert len(result) == 1
        assert result[0].title == "Within 48h"

    def test_empty_task_list_returns_empty(self) -> None:
        assert reminder.get_due_soon_tasks([]) == []
