"""Tests for schedule_suggester.py — rule-based AI schedule logic."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import pytest

import schedule_suggester
from exceptions import InvalidHoursError
from models import Task
from tests.conftest import future


def _task(title: str, priority: str, days: int) -> Task:
    return Task(title=title, subject="S", deadline=future(days), priority=priority)


# ---------------------------------------------------------------------------
# suggest_schedule
# ---------------------------------------------------------------------------

class TestSuggestSchedule:
    def test_empty_task_list_returns_empty_schedule(self) -> None:
        plan, all_scheduled = schedule_suggester.suggest_schedule([], 4.0)
        assert plan == {}
        assert all_scheduled is True

    def test_single_task_appears_in_plan(self) -> None:
        tasks = [_task("Essay", "High", 5)]
        plan, _ = schedule_suggester.suggest_schedule(tasks, 4.0)
        all_entries = [e for entries in plan.values() for e in entries]
        titles = [e["title"] for e in all_entries]
        assert "Essay" in titles

    def test_high_priority_scheduled_before_low_on_first_day(self) -> None:
        tasks = [
            _task("Low task", "Low", 7),
            _task("High task", "High", 7),
        ]
        plan, _ = schedule_suggester.suggest_schedule(tasks, 4.0)
        first_day_entries = plan[min(plan.keys())]
        # High urgency score → first entry
        assert first_day_entries[0]["priority"] == "High"

    def test_completed_tasks_excluded(self) -> None:
        task = _task("Done", "High", 5)
        task.is_complete = True
        plan, all_scheduled = schedule_suggester.suggest_schedule([task], 4.0)
        assert plan == {}
        assert all_scheduled is True

    def test_overdue_tasks_excluded(self) -> None:
        from datetime import datetime, timedelta
        overdue_task = Task(
            title="Old",
            subject="S",
            deadline=datetime.now() - timedelta(hours=1),
            priority="High",
        )
        plan, _ = schedule_suggester.suggest_schedule([overdue_task], 4.0)
        assert plan == {}

    def test_zero_hours_per_day_raises(self) -> None:
        with pytest.raises(InvalidHoursError):
            schedule_suggester.suggest_schedule([_task("T", "Low", 5)], 0)

    def test_all_scheduled_true_when_sufficient_hours(self) -> None:
        tasks = [_task("T1", "High", 10), _task("T2", "Medium", 10)]
        _, all_scheduled = schedule_suggester.suggest_schedule(tasks, 8.0)
        assert all_scheduled is True

    def test_urgency_score_high_greater_than_low(self) -> None:
        today = date.today()
        high = _task("H", "High", 5)
        low = _task("L", "Low", 5)
        assert schedule_suggester._urgency_score(high, today) > schedule_suggester._urgency_score(low, today)

    def test_sooner_deadline_increases_score(self) -> None:
        today = date.today()
        soon = _task("Soon", "Medium", 2)
        later = _task("Later", "Medium", 10)
        assert schedule_suggester._urgency_score(soon, today) > schedule_suggester._urgency_score(later, today)
