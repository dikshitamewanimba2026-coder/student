"""Tests for storage.py — JSON persistence layer."""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import pytest

import storage
from models import StudyLog, Task
from tests.conftest import future


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_task(**kwargs) -> Task:
    defaults = dict(title="T", subject="S", deadline=future(2), priority="High")
    defaults.update(kwargs)
    return Task(**defaults)


def _make_log(**kwargs) -> StudyLog:
    defaults = dict(subject="Math", date=date.today(), hours=1.5)
    defaults.update(kwargs)
    return StudyLog(**defaults)


# ---------------------------------------------------------------------------
# Fixtures that redirect file paths to a temp directory
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _tmp_data(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Redirect DATA_DIR / TASKS_FILE / LOGS_FILE to a temp directory."""
    monkeypatch.setattr(storage, "DATA_DIR", tmp_path)
    monkeypatch.setattr(storage, "TASKS_FILE", tmp_path / "tasks.json")
    monkeypatch.setattr(storage, "LOGS_FILE", tmp_path / "logs.json")


# ---------------------------------------------------------------------------
# Task persistence
# ---------------------------------------------------------------------------

class TestTaskStorage:
    def test_save_and_load_round_trip(self) -> None:
        tasks = [_make_task(title="A"), _make_task(title="B")]
        storage.save_tasks(tasks)
        loaded = storage.load_tasks()
        assert len(loaded) == 2
        assert {t.title for t in loaded} == {"A", "B"}

    def test_load_returns_empty_list_when_file_missing(self) -> None:
        assert storage.load_tasks() == []

    def test_load_returns_empty_list_on_invalid_json(self, tmp_path: Path) -> None:
        storage.TASKS_FILE.write_text("{not valid json", encoding="utf-8")
        assert storage.load_tasks() == []

    def test_load_returns_empty_list_on_empty_file(self, tmp_path: Path) -> None:
        storage.TASKS_FILE.write_text("", encoding="utf-8")
        assert storage.load_tasks() == []

    def test_save_overwrites_previous_content(self) -> None:
        storage.save_tasks([_make_task(title="Old")])
        storage.save_tasks([_make_task(title="New")])
        loaded = storage.load_tasks()
        assert len(loaded) == 1
        assert loaded[0].title == "New"

    def test_saved_file_is_valid_json(self, tmp_path: Path) -> None:
        storage.save_tasks([_make_task()])
        content = storage.TASKS_FILE.read_text(encoding="utf-8")
        parsed = json.loads(content)
        assert isinstance(parsed, list)


# ---------------------------------------------------------------------------
# Log persistence
# ---------------------------------------------------------------------------

class TestLogStorage:
    def test_save_and_load_round_trip(self) -> None:
        logs = [_make_log(subject="Math"), _make_log(subject="Science")]
        storage.save_logs(logs)
        loaded = storage.load_logs()
        assert len(loaded) == 2
        assert {lg.subject for lg in loaded} == {"Math", "Science"}

    def test_load_returns_empty_list_when_file_missing(self) -> None:
        assert storage.load_logs() == []

    def test_load_returns_empty_list_on_invalid_json(self) -> None:
        storage.LOGS_FILE.write_text("bad json!!!", encoding="utf-8")
        assert storage.load_logs() == []
