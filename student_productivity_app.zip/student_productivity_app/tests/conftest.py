"""Shared pytest fixtures for all test modules."""

from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

# Ensure sibling modules (models, storage, …) are importable from tests/
sys.path.insert(0, str(Path(__file__).parent.parent))

from models import ALLOWED_PRIORITIES, StudyLog, Task


def future(days: int = 3, hours: int = 0) -> datetime:
    """Return a datetime *days* (and optional *hours*) in the future."""
    return datetime.now() + timedelta(days=days, hours=hours)


def past(days: int = 1) -> datetime:
    """Return a datetime *days* in the past."""
    return datetime.now() - timedelta(days=days)


@pytest.fixture()
def sample_task() -> Task:
    """A valid pending Task due in 3 days."""
    return Task(
        title="Sample Task",
        subject="Mathematics",
        deadline=future(3),
        priority="High",
    )


@pytest.fixture()
def sample_log(sample_task: Task) -> StudyLog:
    """A valid StudyLog entry."""
    from datetime import date
    return StudyLog(subject="Mathematics", date=date.today(), hours=2.0)
