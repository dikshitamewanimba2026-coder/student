"""Tests for models.py — Task and StudyLog serialisation round-trips."""

from __future__ import annotations

from datetime import date, datetime

import pytest

from models import StudyLog, Task


class TestTaskRoundTrip:
    def test_to_dict_contains_all_fields(self, sample_task: Task) -> None:
        d = sample_task.to_dict()
        assert set(d.keys()) == {
            "task_id", "title", "subject", "deadline",
            "priority", "is_complete", "created_at",
        }

    def test_from_dict_restores_task(self, sample_task: Task) -> None:
        restored = Task.from_dict(sample_task.to_dict())
        assert restored.task_id == sample_task.task_id
        assert restored.title == sample_task.title
        assert restored.subject == sample_task.subject
        assert restored.priority == sample_task.priority
        assert restored.is_complete == sample_task.is_complete

    def test_deadline_survives_round_trip(self, sample_task: Task) -> None:
        restored = Task.from_dict(sample_task.to_dict())
        # isoformat round-trip may truncate microseconds — compare to second
        assert abs((restored.deadline - sample_task.deadline).total_seconds()) < 1

    def test_is_complete_default_is_false(self) -> None:
        task = Task(
            title="T",
            subject="S",
            deadline=datetime.now().replace(year=datetime.now().year + 1),
            priority="Low",
        )
        assert task.is_complete is False


class TestStudyLogRoundTrip:
    def test_to_dict_contains_all_fields(self, sample_log: "StudyLog") -> None:
        d = sample_log.to_dict()
        assert set(d.keys()) == {"log_id", "subject", "date", "hours"}

    def test_from_dict_restores_log(self, sample_log: "StudyLog") -> None:
        restored = StudyLog.from_dict(sample_log.to_dict())
        assert restored.log_id == sample_log.log_id
        assert restored.subject == sample_log.subject
        assert restored.date == sample_log.date
        assert restored.hours == sample_log.hours

    def test_date_type_after_round_trip(self, sample_log: "StudyLog") -> None:
        restored = StudyLog.from_dict(sample_log.to_dict())
        assert isinstance(restored.date, date)
