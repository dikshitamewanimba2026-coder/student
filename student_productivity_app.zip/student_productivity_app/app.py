"""Streamlit entry point for the Student Productivity & Time Management App.

All business logic lives in the separate modules (task_manager, study_tracker,
schedule_suggester, reminder).  This file only handles UI rendering and calls
those modules for data operations.
"""

from __future__ import annotations

import sys
from datetime import date, datetime, time
from pathlib import Path

import streamlit as st

# ---------------------------------------------------------------------------
# Make sure sibling modules are importable when launched via
# `streamlit run app.py` from any working directory.
# ---------------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).parent))

import reminder
import schedule_suggester
import storage
import study_tracker
import task_manager
from exceptions import (
    EmptyTitleError,
    InvalidDeadlineError,
    InvalidHoursError,
    InvalidPriorityError,
    TaskNotFoundError,
)
from models import ALLOWED_PRIORITIES

# ---------------------------------------------------------------------------
# Page configuration
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Student Productivity App",
    page_icon="📚",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Sidebar — global settings
# ---------------------------------------------------------------------------
with st.sidebar:
    st.title("📚 Student Productivity")
    st.markdown("---")
    available_hours = st.number_input(
        "Study hours available per day",
        min_value=0.5,
        max_value=16.0,
        value=4.0,
        step=0.5,
        help="Used by the AI schedule suggester.",
    )
    reminder_threshold = st.number_input(
        "Reminder threshold (hours)",
        min_value=1,
        max_value=168,
        value=48,
        step=1,
        help="Show a reminder banner for tasks due within this many hours.",
    )
    st.markdown("---")
    st.caption("Data stored in `data/tasks.json` and `data/logs.json`.")

# ---------------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------------
tab_tasks, tab_schedule, tab_log, tab_summary = st.tabs(
    ["📝 My Tasks", "📅 Study Schedule", "⏱️ Log Hours", "📊 Summary"]
)


# ===========================================================================
# TAB 1 — MY TASKS
# ===========================================================================
with tab_tasks:
    st.header("My Tasks")

    # ── Reminder banners ────────────────────────────────────────────────────
    all_tasks = storage.load_tasks()
    due_soon = reminder.get_due_soon_tasks(all_tasks, threshold_hours=float(reminder_threshold))
    if due_soon:
        for t in due_soon:
            delta = t.deadline - datetime.now()
            hours_left = int(delta.total_seconds() // 3600)
            st.warning(
                f"⏰ **{t.title}** ({t.subject}) is due in ~{hours_left} hour{'s' if hours_left != 1 else ''}!",
                icon="⚠️",
            )

    st.markdown("---")

    # ── Add task form ────────────────────────────────────────────────────────
    with st.expander("➕ Add New Task", expanded=True):
        with st.form("add_task_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            with col1:
                new_title = st.text_input("Task title *", placeholder="e.g. Chapter 5 revision")
                new_subject = st.text_input("Subject *", placeholder="e.g. Mathematics")
            with col2:
                new_priority = st.selectbox("Priority *", list(ALLOWED_PRIORITIES))
                new_deadline_date = st.date_input(
                    "Deadline date *",
                    value=date.today(),
                    min_value=date.today(),
                )
                new_deadline_time = st.time_input("Deadline time *", value=time(23, 59))

            submitted = st.form_submit_button("Add Task", type="primary")
            if submitted:
                deadline_dt = datetime.combine(new_deadline_date, new_deadline_time)
                try:
                    task_manager.add_task(
                        title=new_title,
                        subject=new_subject,
                        deadline=deadline_dt,
                        priority=new_priority,
                    )
                    st.success(f"✅ Task **{new_title}** added successfully!")
                    st.rerun()
                except (EmptyTitleError, InvalidDeadlineError, InvalidPriorityError) as exc:
                    st.error(f"❌ {exc}")

    st.markdown("---")

    # ── Pending tasks ────────────────────────────────────────────────────────
    pending = task_manager.get_pending_tasks()
    overdue = [t for t in pending if task_manager.get_time_remaining(t) == "Overdue"]
    upcoming = [t for t in pending if task_manager.get_time_remaining(t) != "Overdue"]

    # Overdue section
    if overdue:
        st.subheader(f"🔴 Overdue ({len(overdue)})")
        for task in overdue:
            cols = st.columns([4, 2, 1, 1])
            cols[0].markdown(f"**{task.title}** — _{task.subject}_")
            cols[1].markdown(f"Due: `{task.deadline.strftime('%d %b %Y %H:%M')}`")
            cols[2].button(
                "✔ Done",
                key=f"done_{task.task_id}",
                on_click=task_manager.toggle_complete,
                args=(task.task_id,),
            )
            cols[3].button(
                "🗑 Delete",
                key=f"del_{task.task_id}",
                on_click=task_manager.delete_task,
                args=(task.task_id,),
            )

    # Upcoming section
    st.subheader(f"🟡 Pending ({len(upcoming)})")
    if not upcoming and not overdue:
        st.info("No pending tasks. Add one above!")
    for task in upcoming:
        priority_colour = {"High": "🔴", "Medium": "🟠", "Low": "🟢"}.get(task.priority, "⚪")
        time_left = task_manager.get_time_remaining(task)
        cols = st.columns([3, 2, 2, 1, 1])
        cols[0].markdown(f"{priority_colour} **{task.title}** — _{task.subject}_")
        cols[1].markdown(f"Due: `{task.deadline.strftime('%d %b %Y %H:%M')}`")
        cols[2].markdown(f"⏳ {time_left}")
        cols[3].button(
            "✔ Done",
            key=f"done_{task.task_id}",
            on_click=task_manager.toggle_complete,
            args=(task.task_id,),
        )
        cols[4].button(
            "🗑 Delete",
            key=f"del_{task.task_id}",
            on_click=task_manager.delete_task,
            args=(task.task_id,),
        )

    # ── Completed tasks ──────────────────────────────────────────────────────
    completed = task_manager.get_completed_tasks()
    if completed:
        with st.expander(f"✅ Completed tasks ({len(completed)})"):
            for task in completed:
                cols = st.columns([4, 2, 1])
                cols[0].markdown(f"~~{task.title}~~ — _{task.subject}_")
                cols[1].markdown(f"Was due: `{task.deadline.strftime('%d %b %Y %H:%M')}`")
                cols[2].button(
                    "↩ Undo",
                    key=f"undo_{task.task_id}",
                    on_click=task_manager.toggle_complete,
                    args=(task.task_id,),
                )


# ===========================================================================
# TAB 2 — STUDY SCHEDULE (AI SUGGESTER)
# ===========================================================================
with tab_schedule:
    st.header("📅 Suggested Study Schedule")
    st.caption(
        "Schedule is generated using a rule-based urgency score: "
        "**score = (priority_weight ÷ days_remaining) + priority_weight**. "
        "Higher-priority and sooner-due tasks are always scheduled first."
    )

    all_tasks_for_schedule = storage.load_tasks()
    try:
        plan, all_scheduled = schedule_suggester.suggest_schedule(
            all_tasks_for_schedule,
            available_hours_per_day=available_hours,
        )
    except InvalidHoursError as exc:
        st.error(str(exc))
        plan, all_scheduled = {}, True

    if not plan:
        st.info("No pending tasks to schedule. Add tasks in the **My Tasks** tab.")
    else:
        if not all_scheduled:
            st.warning(
                "⚠️ Not all tasks could be fully scheduled within the available hours. "
                "Consider increasing your daily study hours in the sidebar."
            )

        for day, entries in sorted(plan.items()):
            label = (
                "Today"
                if day == date.today()
                else "Tomorrow"
                if day == date.today().replace(day=date.today().day + 1)
                else day.strftime("%A, %d %b %Y")
            )
            with st.expander(f"📆 {label}  —  {sum(e['hours'] for e in entries):.1f} hrs", expanded=(day == date.today())):
                for entry in entries:
                    priority_icon = {"High": "🔴", "Medium": "🟠", "Low": "🟢"}.get(entry["priority"], "⚪")
                    st.markdown(
                        f"{priority_icon} **{entry['title']}** ({entry['subject']}) — "
                        f"`{entry['hours']} hr{'s' if entry['hours'] != 1 else ''}`"
                    )


# ===========================================================================
# TAB 3 — LOG STUDY HOURS
# ===========================================================================
with tab_log:
    st.header("⏱️ Log Study Hours")

    with st.form("log_hours_form", clear_on_submit=True):
        col1, col2, col3 = st.columns(3)
        with col1:
            log_subject = st.text_input("Subject *", placeholder="e.g. Physics")
        with col2:
            log_date = st.date_input("Date *", value=date.today(), max_value=date.today())
        with col3:
            log_hours_val = st.number_input(
                "Hours studied *",
                min_value=0.1,
                max_value=12.0,
                value=1.0,
                step=0.25,
            )
        log_submitted = st.form_submit_button("Log Hours", type="primary")
        if log_submitted:
            try:
                study_tracker.log_hours(log_subject, log_date, log_hours_val)
                st.success(f"✅ Logged {log_hours_val} hr(s) for **{log_subject}** on {log_date}.")
                st.rerun()
            except (EmptyTitleError, InvalidHoursError) as exc:
                st.error(f"❌ {exc}")

    st.markdown("---")
    st.subheader("Today's Sessions")
    logs = storage.load_logs()
    today_logs = [lg for lg in logs if lg.date == date.today()]
    if today_logs:
        for lg in sorted(today_logs, key=lambda l: l.subject):
            st.markdown(f"- **{lg.subject}**: {lg.hours} hr{'s' if lg.hours != 1 else ''}")
    else:
        st.info("Nothing logged today yet.")


# ===========================================================================
# TAB 4 — PRODUCTIVITY SUMMARY
# ===========================================================================
with tab_summary:
    st.header("📊 Productivity Summary")

    all_tasks_summary = storage.load_tasks()
    total = len(all_tasks_summary)
    n_complete = sum(1 for t in all_tasks_summary if t.is_complete)
    n_pending = total - n_complete
    pct = round((n_complete / total) * 100) if total else 0
    weekly_hrs = study_tracker.get_weekly_hours()
    hours_by_subject = study_tracker.get_hours_by_subject()

    # ── Top metrics ──────────────────────────────────────────────────────────
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Total Tasks", total)
    m2.metric("Pending", n_pending)
    m3.metric("Completed", n_complete)
    m4.metric("Completion %", f"{pct}%")
    m5.metric("Study hrs this week", f"{weekly_hrs} hrs")

    st.markdown("---")

    col_left, col_right = st.columns(2)

    # ── Hours by subject ─────────────────────────────────────────────────────
    with col_left:
        st.subheader("Hours by Subject (all time)")
        if hours_by_subject:
            st.bar_chart(hours_by_subject)
        else:
            st.info("No study hours logged yet.")

    # ── Overdue tasks ─────────────────────────────────────────────────────────
    with col_right:
        st.subheader("⚠️ Overdue Tasks")
        overdue_summary = [
            t for t in all_tasks_summary
            if not t.is_complete and task_manager.get_time_remaining(t) == "Overdue"
        ]
        if overdue_summary:
            for t in overdue_summary:
                st.error(
                    f"**{t.title}** ({t.subject}) — was due "
                    f"`{t.deadline.strftime('%d %b %Y %H:%M')}` [{t.priority}]"
                )
        else:
            st.success("No overdue tasks. 🎉")
