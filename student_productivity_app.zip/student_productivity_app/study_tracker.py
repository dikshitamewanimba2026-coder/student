"""Study hour logging and summary queries."""

from __future__ import annotations

from datetime import date

import storage
from exceptions import EmptyTitleError, InvalidHoursError
from models import StudyLog

_MAX_HOURS_PER_SESSION = 12.0


def log_hours(subject: str, log_date: date, hours: float) -> StudyLog:
    """Log study hours for *subject* on *log_date*.

    If a log for the same subject + date already exists, the *hours* value
    is **accumulated** (added to the existing entry) rather than overwritten.

    Parameters
    ----------
    subject:  Name of the subject studied (non-empty).
    log_date: The date of the study session.
    hours:    Hours studied — must be ``0 < hours <= 12``.

    Returns
    -------
    The new or updated :class:`~models.StudyLog`.

    Raises
    ------
    EmptyTitleError:  *subject* is blank/whitespace.
    InvalidHoursError: *hours* is <= 0 or > 12.
    """
    if not subject or not subject.strip():
        raise EmptyTitleError("Subject cannot be empty.")
    if hours <= 0 or hours > _MAX_HOURS_PER_SESSION:
        raise InvalidHoursError(
            f"Study hours must be between 0 (exclusive) and {_MAX_HOURS_PER_SESSION} (inclusive), got {hours}."
        )

    logs = storage.load_logs()
    subject = subject.strip()

    # Look for an existing entry to accumulate
    for log in logs:
        if log.subject == subject and log.date == log_date:
            log.hours = round(log.hours + hours, 2)
            storage.save_logs(logs)
            return log

    # No existing entry — create a new one
    new_log = StudyLog(subject=subject, date=log_date, hours=hours)
    logs.append(new_log)
    storage.save_logs(logs)
    return new_log


def get_weekly_hours() -> float:
    """Return the total study hours logged during the current Mon–Sun week."""
    today = date.today()
    # weekday() returns 0=Monday … 6=Sunday
    week_start = today.replace(day=today.day - today.weekday())
    week_end = week_start.replace(day=week_start.day + 6)

    logs = storage.load_logs()
    total = sum(lg.hours for lg in logs if week_start <= lg.date <= week_end)
    return round(total, 2)


def get_hours_by_subject() -> dict[str, float]:
    """Return a mapping of subject name → total hours studied (all time)."""
    logs = storage.load_logs()
    result: dict[str, float] = {}
    for lg in logs:
        result[lg.subject] = round(result.get(lg.subject, 0.0) + lg.hours, 2)
    return result
