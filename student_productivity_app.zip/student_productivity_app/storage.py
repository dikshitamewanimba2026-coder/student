"""JSON-backed persistence layer for tasks and study logs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Union

from models import StudyLog, Task

# ---------------------------------------------------------------------------
# Paths — resolved relative to this file so the app works regardless of the
# current working directory when `streamlit run app.py` is called.
# ---------------------------------------------------------------------------
_HERE = Path(__file__).parent
DATA_DIR = _HERE / "data"
TASKS_FILE = DATA_DIR / "tasks.json"
LOGS_FILE = DATA_DIR / "logs.json"


def _ensure_data_dir() -> None:
    """Create the data directory if it does not exist."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

def load_tasks() -> list[Task]:
    """Load all tasks from *tasks.json*.

    Returns an empty list when the file is missing, empty, or contains
    invalid JSON — the app should never crash on a bad data file.
    """
    _ensure_data_dir()
    if not TASKS_FILE.exists():
        return []
    try:
        raw = TASKS_FILE.read_text(encoding="utf-8").strip()
        if not raw:
            return []
        records: list[dict] = json.loads(raw)
        return [Task.from_dict(r) for r in records]
    except (json.JSONDecodeError, KeyError, ValueError) as exc:
        print(f"[storage] Could not load tasks.json: {exc} — returning empty list.")
        return []


def save_tasks(tasks: list[Task]) -> None:
    """Persist *tasks* to *tasks.json*, overwriting any previous content."""
    _ensure_data_dir()
    TASKS_FILE.write_text(
        json.dumps([t.to_dict() for t in tasks], indent=2),
        encoding="utf-8",
    )


# ---------------------------------------------------------------------------
# Study Logs
# ---------------------------------------------------------------------------

def load_logs() -> list[StudyLog]:
    """Load all study logs from *logs.json*.

    Returns an empty list when the file is missing, empty, or contains
    invalid JSON.
    """
    _ensure_data_dir()
    if not LOGS_FILE.exists():
        return []
    try:
        raw = LOGS_FILE.read_text(encoding="utf-8").strip()
        if not raw:
            return []
        records: list[dict] = json.loads(raw)
        return [StudyLog.from_dict(r) for r in records]
    except (json.JSONDecodeError, KeyError, ValueError) as exc:
        print(f"[storage] Could not load logs.json: {exc} — returning empty list.")
        return []


def save_logs(logs: list[StudyLog]) -> None:
    """Persist *logs* to *logs.json*, overwriting any previous content."""
    _ensure_data_dir()
    LOGS_FILE.write_text(
        json.dumps([lg.to_dict() for lg in logs], indent=2),
        encoding="utf-8",
    )
