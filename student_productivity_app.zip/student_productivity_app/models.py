"""Data models for the Student Productivity App."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any


ALLOWED_PRIORITIES: tuple[str, ...] = ("High", "Medium", "Low")


@dataclass
class Task:
    """Represents a student task or assignment."""

    title: str
    subject: str
    deadline: datetime
    priority: str
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    is_complete: bool = False
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a JSON-safe dictionary."""
        return {
            "task_id": self.task_id,
            "title": self.title,
            "subject": self.subject,
            "deadline": self.deadline.isoformat(),
            "priority": self.priority,
            "is_complete": self.is_complete,
            "created_at": self.created_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Task":
        """Deserialise from a dictionary produced by :meth:`to_dict`."""
        return cls(
            task_id=data["task_id"],
            title=data["title"],
            subject=data["subject"],
            deadline=datetime.fromisoformat(data["deadline"]),
            priority=data["priority"],
            is_complete=data["is_complete"],
            created_at=datetime.fromisoformat(data["created_at"]),
        )


@dataclass
class StudyLog:
    """Represents a single study session logged by the student."""

    subject: str
    date: date
    hours: float
    log_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a JSON-safe dictionary."""
        return {
            "log_id": self.log_id,
            "subject": self.subject,
            "date": self.date.isoformat(),
            "hours": self.hours,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StudyLog":
        """Deserialise from a dictionary produced by :meth:`to_dict`."""
        return cls(
            log_id=data["log_id"],
            subject=data["subject"],
            date=date.fromisoformat(data["date"]),
            hours=data["hours"],
        )
