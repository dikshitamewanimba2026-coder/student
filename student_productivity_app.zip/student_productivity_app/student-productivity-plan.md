# Student Productivity App — Implementation Plan

## Top-Level Overview

**Goal:** Build a single-user, AI-assisted Student Productivity & Time Management app
using Python and Streamlit. The app lets a student manage tasks/assignments, log study
hours, receive rule-based daily schedule suggestions, see productivity summaries, and
get in-app deadline reminders.

**Scope:**
- New project in `student_productivity_app/` on the Desktop
- Pure Python + Streamlit (no external AI/ML libraries)
- Persistence via two local JSON files: `tasks.json` and `logs.json`
- Rule-based schedule suggester (priority + deadline sort, hours division)
- pytest unit tests for every non-UI module
- No authentication, no multi-user support, no email/SMS

**Approach:** Build bottom-up — data models first, then storage, then business logic,
then the AI suggester, then the Streamlit UI, then tests. Each milestone is
independently verifiable before the next begins.

**Project folder structure (target state):**
```
student_productivity_app/
├── app.py                  # Streamlit entry point
├── models.py               # Task and StudyLog dataclasses
├── storage.py              # JSON read/write for tasks and logs
├── task_manager.py         # Task CRUD + time-remaining logic
├── study_tracker.py        # Study hour logging + weekly/subject summaries
├── schedule_suggester.py   # Rule-based daily schedule generator
├── reminder.py             # Due-soon task detection
├── exceptions.py           # Custom exception classes
├── data/
│   ├── tasks.json          # Persisted task records
│   └── logs.json           # Persisted study log records
└── tests/
    ├── test_models.py
    ├── test_storage.py
    ├── test_task_manager.py
    ├── test_study_tracker.py
    ├── test_schedule_suggester.py
    └── test_reminder.py
```

---

## Milestone 1 — Data Models & Custom Exceptions

**Status:** `[ ] pending`

### Intent
Define the canonical data structures (`Task`, `StudyLog`) and all custom exceptions
the rest of the system will import. Getting these right first means every other module
builds on a stable foundation with no circular imports.

### Expected Outcomes
- `models.py` exists with `Task` and `StudyLog` as Python `dataclasses`
- `exceptions.py` exists with all five custom exception classes
- Both files are importable with no errors
- All fields, types, and defaults match the data field specification

### Todo List
1. Create `student_productivity_app/` root folder and `data/` and `tests/` subfolders
2. Create `models.py`:
   - `Task` dataclass with fields: `task_id` (str, default=uuid4), `title` (str),
     `subject` (str), `deadline` (datetime), `priority` (str), `is_complete` (bool,
     default=False), `created_at` (datetime, default=now)
   - `StudyLog` dataclass with fields: `log_id` (str, default=uuid4), `subject` (str),
     `date` (date), `hours` (float)
   - Both dataclasses should be serialisable to/from plain dicts (add `to_dict()` and
     `from_dict()` class/static methods to each)
3. Create `exceptions.py` with: `InvalidDeadlineError`, `InvalidPriorityError`,
   `InvalidHoursError`, `TaskNotFoundError`, `EmptyTitleError` — all subclass
   `ValueError`

### Relevant Context
- Priority allowed values: `"High"`, `"Medium"`, `"Low"`
- `task_id` and `log_id` should use `uuid.uuid4()` as a string default factory
- `created_at` should default to `datetime.now()`
- `to_dict()` must convert `datetime`/`date` fields to ISO strings so JSON can store them
- `from_dict()` must parse ISO strings back to `datetime`/`date` objects

---

## Milestone 2 — Storage Layer

**Status:** `[ ] pending`

### Intent
Build the single module that reads and writes `tasks.json` and `logs.json`. Every other
module that needs persistence will call only this layer — it is the only place that
touches the filesystem.

### Expected Outcomes
- `storage.py` exists with four functions: `load_tasks`, `save_tasks`, `load_logs`,
  `save_logs`
- If a JSON file does not exist or is empty, the load functions return an empty list
  (no crash)
- Saving and reloading a list of Tasks/StudyLogs produces identical objects
- The `data/` directory is created automatically if missing

### Todo List
1. Create `storage.py`
2. Implement `load_tasks() -> list[Task]`: reads `data/tasks.json`, deserialises each
   record via `Task.from_dict()`, returns list; returns `[]` if file missing or empty
3. Implement `save_tasks(tasks: list[Task]) -> None`: serialises via `task.to_dict()`,
   writes to `data/tasks.json` with `indent=2`
4. Implement `load_logs() -> list[StudyLog]`: same pattern using `StudyLog.from_dict()`
5. Implement `save_logs(logs: list[StudyLog]) -> None`: same pattern using
   `log.to_dict()`
6. Handle `json.JSONDecodeError` on load by returning `[]` and (optionally) printing a
   warning — never crash the app on a corrupted file

### Relevant Context
- File paths should be built relative to this file using `pathlib.Path`
- Use `Path(__file__).parent / "data" / "tasks.json"` style paths so the app works
  regardless of where it is launched from
- `data/` directory should be created with `mkdir(parents=True, exist_ok=True)`

---

## Milestone 3 — Task Manager (Business Logic)

**Status:** `[ ] pending`

### Intent
Implement all task-related operations: creating, deleting, toggling completion, and
computing time remaining. This module enforces all business rules and raises custom
exceptions when input is invalid.

### Expected Outcomes
- `task_manager.py` exists with five functions
- All BR-1 through BR-5 business rules are enforced with appropriate exceptions
- `get_time_remaining` returns a human-readable string (e.g. `"2 days, 3 hours"`) or
  `"Overdue"` for past deadlines
- `get_pending_tasks` returns tasks sorted: High priority first, then by nearest
  deadline

### Todo List
1. Create `task_manager.py`
2. Implement `add_task(title, subject, deadline, priority) -> Task`:
   - Raise `EmptyTitleError` if title is blank/whitespace
   - Raise `EmptyTitleError` if subject is blank/whitespace
   - Raise `InvalidDeadlineError` if deadline is not in the future
   - Raise `InvalidPriorityError` if priority not in `{"High", "Medium", "Low"}`
   - Construct `Task`, append to loaded list, save, return new Task
3. Implement `delete_task(task_id: str) -> None`:
   - Raise `TaskNotFoundError` if ID not found
   - Remove from list and save
4. Implement `toggle_complete(task_id: str) -> Task`:
   - Raise `TaskNotFoundError` if ID not found
   - Flip `is_complete`, save, return updated Task
5. Implement `get_pending_tasks() -> list[Task]`:
   - Return all tasks where `is_complete == False`
   - Sort: priority order High→Medium→Low, then by `deadline` ascending
6. Implement `get_completed_tasks() -> list[Task]`:
   - Return all tasks where `is_complete == True`, sorted by `deadline` ascending
7. Implement `get_time_remaining(task: Task) -> str`:
   - If deadline is in the past: return `"Overdue"`
   - Otherwise: compute delta and return a string like `"3 days, 4 hours"` or
     `"5 hours, 30 minutes"` (only show the two most significant units)

### Relevant Context
- Priority sort order mapping: `{"High": 0, "Medium": 1, "Low": 2}` — sort ascending
- "Future" for deadline validation means `deadline > datetime.now()` at the moment
  `add_task` is called
- All load/save calls go through `storage.py` — task_manager must not touch files
  directly

---

## Milestone 4 — Study Tracker (Business Logic)

**Status:** `[ ] pending`

### Intent
Implement study hour logging and all summary queries. This module is independent of
tasks — study logs are their own entity and stand alone.

### Expected Outcomes
- `study_tracker.py` exists with three functions
- Hours for the same subject on the same date accumulate (not overwritten)
- `get_weekly_hours` counts only the current Monday–Sunday calendar week
- `get_hours_by_subject` returns a dict keyed by subject name

### Todo List
1. Create `study_tracker.py`
2. Implement `log_hours(subject: str, date: date, hours: float) -> StudyLog`:
   - Raise `InvalidHoursError` if `hours <= 0` or `hours > 12`
   - Raise `EmptyTitleError` if subject is blank
   - If a log for the same subject + date already exists, update its `hours` by adding
     the new value (accumulate), save, return the updated log
   - Otherwise create a new `StudyLog`, append, save, return it
3. Implement `get_weekly_hours() -> float`:
   - Determine current week's Monday and Sunday using `date.today()` and
     `date.weekday()`
   - Sum `hours` for all logs whose `date` falls in that range
   - Return total as a float
4. Implement `get_hours_by_subject() -> dict[str, float]`:
   - Aggregate all logs, summing hours per subject name
   - Return `{"Math": 5.5, "Physics": 3.0, ...}`

### Relevant Context
- `date.weekday()` returns 0 for Monday, 6 for Sunday — use this to compute week
  boundaries
- All load/save calls go through `storage.py`

---

## Milestone 5 — Schedule Suggester (Rule-Based AI)

**Status:** `[ ] pending`

### Intent
Build the rule-based schedule generator. Given the list of pending tasks and how many
hours per day the student is available, it produces a day-by-day study plan that
respects priority and deadline ordering.

### Expected Outcomes
- `schedule_suggester.py` exists with one public function and one private helper
- The output is a dict mapping a `date` to a list of schedule entries
- High-priority tasks appear before lower-priority tasks on any given day
- Tasks are never scheduled after their deadline
- If available hours are too few to fit all tasks, a warning flag is returned alongside
  the plan

### Todo List
1. Create `schedule_suggester.py`
2. Implement `_priority_score(task: Task) -> int`:
   - Returns `0` for High, `1` for Medium, `2` for Low
3. Implement `suggest_schedule(tasks: list[Task], available_hours_per_day: float) -> dict`:
   - Validate `available_hours_per_day > 0`; raise `InvalidHoursError` if not
   - Filter to pending, non-overdue tasks only
   - Sort tasks by `(_priority_score, deadline, created_at)`
   - Assign each task a suggested study duration: `min(2.0, days_until_deadline * 0.5)`
     hours capped at 2 hours per day per task (configurable constant `MAX_HOURS_PER_TASK_PER_DAY = 2.0`)
   - Walk forward from today, filling each day up to `available_hours_per_day` with
     task slots, never scheduling a task on or after its deadline date
   - Return structure:
     ```
     {
       date(2025, 7, 15): [
         {"task_id": "...", "title": "...", "subject": "...", "hours": 1.5},
         ...
       ],
       ...
     }
     ```
   - Also return a boolean `all_scheduled` indicating whether every task got time
     (return as a tuple: `(schedule_dict, all_scheduled)`)
4. If `tasks` is empty, return `({}, True)` immediately

### Relevant Context
- "Today" means `date.today()` — never schedule on past dates
- A task is overdue if `task.deadline.date() < date.today()`
- The suggester is read-only — it never calls storage directly
- The `available_hours_per_day` setting will come from a Streamlit sidebar input in
  the UI milestone

---

## Milestone 6 — Reminder Module

**Status:** `[ ] pending`

### Intent
Implement the simple due-soon detection logic that the UI will call to display alert
banners. This is intentionally small — a single function.

### Expected Outcomes
- `reminder.py` exists with one function
- Returns only pending, non-overdue tasks whose deadline is within `threshold_hours`
- Results are sorted by deadline ascending (most urgent first)

### Todo List
1. Create `reminder.py`
2. Implement `get_due_soon_tasks(tasks: list[Task], threshold_hours: float = 48.0) -> list[Task]`:
   - Filter to tasks where `is_complete == False`
   - Filter to tasks where `0 < time_until_deadline <= threshold_hours * 3600 seconds`
   - Sort by `deadline` ascending
   - Return the filtered, sorted list

### Relevant Context
- Use `(task.deadline - datetime.now()).total_seconds()` for the time check
- Default threshold is 48 hours but the UI can pass a different value
- This module is read-only — no storage calls

---

## Milestone 7 — Streamlit UI

**Status:** `[ ] pending`

### Intent
Build the four-tab Streamlit interface that wires all business logic modules together
into a usable app. The UI layer contains no business logic of its own — it only calls
the modules built in Milestones 3–6.

### Expected Outcomes
- `app.py` runs with `streamlit run app.py` without errors
- All four tabs are functional and display correct data
- Reminder banners appear at the top of the My Tasks tab when tasks are due soon
- The schedule suggester tab shows a per-day breakdown or a friendly empty state
- Forms validate input and show error messages (not raw exceptions) on bad input

### Todo List
1. Create `app.py` with a page config (title, icon, wide layout)
2. Add a **sidebar** with:
   - App title/logo text
   - "Available study hours per day" number input (default 4.0, range 0.5–16.0)
   - "Reminder threshold (hours)" number input (default 48, range 1–168)
3. Build **Tab 1 — My Tasks**:
   - Call `get_due_soon_tasks` and display a `st.warning` banner for each due-soon task
   - Form to add a new task: title, subject, date+time picker for deadline, priority
     selectbox — on submit call `add_task`, show success or error message
   - Table/list of pending tasks with a "Mark Complete" button per row and a
     "Delete" button per row
   - Expandable section showing completed tasks with a "Mark Incomplete" button per row
   - Each task row shows: title, subject, priority badge, deadline, time remaining
4. Build **Tab 2 — Study Schedule**:
   - Call `suggest_schedule` with pending tasks and sidebar hours value
   - If `all_scheduled` is False, show a `st.warning` that not all tasks could be fit
   - Display the schedule as a day-by-day breakdown using `st.expander` per day
   - Show friendly empty state if no tasks are pending
5. Build **Tab 3 — Log Study Hours**:
   - Form: subject (text input), date (date picker, default today), hours (number input)
   - On submit call `log_hours`, show success or error message
   - Below the form show a summary table of today's logged sessions
6. Build **Tab 4 — Productivity Summary**:
   - Metrics row: total tasks, pending count, completed count, completion percentage
   - Weekly study hours metric (call `get_weekly_hours`)
   - Hours by subject: display as a simple table or `st.bar_chart`
   - List of overdue tasks (deadline in past, still incomplete) with a red indicator

### Relevant Context
- Catch each custom exception in form submit handlers and display with `st.error()`
  rather than letting Streamlit crash
- Use `st.session_state` to avoid re-running expensive loads on every widget interaction
  if needed, but keep it simple — reloading from JSON on each page render is acceptable
  at this scale
- Streamlit re-runs the entire script on each interaction — no explicit refresh needed

---

## Milestone 8 — Persistence Verification

**Status:** `[ ] pending`

### Intent
Confirm that the JSON persistence layer survives a full round-trip: add data through
the UI, stop the app, restart it, and verify data is still present. This is a manual
verification milestone, not a new code milestone.

### Expected Outcomes
- Adding a task, restarting the app, and reopening it shows the task still present
- Logging study hours, restarting, and reopening shows the logged hours still present
- `data/tasks.json` and `data/logs.json` contain valid, human-readable JSON

### Todo List
1. Run `streamlit run app.py`, add two tasks with different priorities and deadlines
2. Stop the app (Ctrl+C), inspect `data/tasks.json` manually to confirm correct JSON
3. Restart the app and confirm both tasks appear in the My Tasks tab
4. Log study hours for two subjects, stop, restart, confirm logs appear in Summary tab
5. Manually corrupt `data/tasks.json` (delete one brace), restart, confirm the app
   shows an empty task list rather than crashing

### Relevant Context
- If any round-trip fails, the bug is in `storage.py` `to_dict`/`from_dict` — check
  datetime ISO format handling first

---

## Milestone 9 — Unit Tests

**Status:** `[ ] pending`

### Intent
Write pytest unit tests for all five logic modules. Tests run without a running
Streamlit server and without touching the real `data/` files — they use temporary
directories or in-memory mocking.

### Expected Outcomes
- `pytest tests/` passes with no failures
- Every public function in `models.py`, `storage.py`, `task_manager.py`,
  `study_tracker.py`, `schedule_suggester.py`, and `reminder.py` has at least one test
- Edge cases identified in the analysis are covered as individual test cases

### Todo List
1. Create `tests/__init__.py` (empty)
2. Write `tests/test_models.py`:
   - Test `Task.to_dict()` and `Task.from_dict()` round-trip
   - Test `StudyLog.to_dict()` and `StudyLog.from_dict()` round-trip
3. Write `tests/test_storage.py` (use `tmp_path` pytest fixture to avoid touching real data):
   - Test `save_tasks` + `load_tasks` round-trip
   - Test `load_tasks` returns `[]` when file does not exist
   - Test `load_tasks` returns `[]` when file contains invalid JSON
4. Write `tests/test_task_manager.py`:
   - Test `add_task` succeeds with valid input
   - Test `add_task` raises `EmptyTitleError` for blank title
   - Test `add_task` raises `InvalidDeadlineError` for past deadline
   - Test `add_task` raises `InvalidPriorityError` for bad priority
   - Test `delete_task` removes the task
   - Test `delete_task` raises `TaskNotFoundError` for unknown ID
   - Test `toggle_complete` flips status correctly
   - Test `get_pending_tasks` returns correct sort order
   - Test `get_time_remaining` returns "Overdue" for past deadline
   - Test `get_time_remaining` returns a non-empty string for future deadline
5. Write `tests/test_study_tracker.py`:
   - Test `log_hours` creates a new log
   - Test `log_hours` accumulates on same subject+date
   - Test `log_hours` raises `InvalidHoursError` for hours <= 0
   - Test `log_hours` raises `InvalidHoursError` for hours > 12
   - Test `get_weekly_hours` sums only current week
   - Test `get_hours_by_subject` aggregates correctly
6. Write `tests/test_schedule_suggester.py`:
   - Test returns empty dict for no tasks
   - Test high-priority task appears before low-priority on same day
   - Test overdue tasks are excluded from schedule
   - Test `all_scheduled` is False when hours are too few
7. Write `tests/test_reminder.py`:
   - Test returns only tasks within threshold
   - Test excludes completed tasks
   - Test excludes overdue tasks
   - Test results are sorted by deadline ascending

### Relevant Context
- Use `pytest` fixtures and `tmp_path` to redirect storage file paths during tests —
  patch the `DATA_DIR` constant in `storage.py` using `monkeypatch` or dependency
  injection
- Tests should not depend on each other or on execution order
- A `conftest.py` can hold shared fixtures (e.g. a factory function for creating test
  Tasks with a future deadline)

---

## Milestone Order & Dependencies

```
Milestone 1 (Models + Exceptions)
        ↓
Milestone 2 (Storage)
        ↓
Milestone 3 (Task Manager)    Milestone 4 (Study Tracker)
        ↓                              ↓
Milestone 5 (Schedule Suggester)   Milestone 6 (Reminder)
        ↓                              ↓
              Milestone 7 (Streamlit UI)
                        ↓
              Milestone 8 (Persistence Verification)
                        ↓
              Milestone 9 (Unit Tests)
```

Milestones 3 and 4 can be built in parallel.
Milestones 5 and 6 can be built in parallel after 3 and 4 respectively.
Milestone 7 requires all of 3–6 to be complete.
